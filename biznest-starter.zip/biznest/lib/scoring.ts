// Guidance score, NOT a credit score. Inputs are 0-100. Weights must be reviewed before launch.
export type ScoreInput = { cashFlow: number; consistency: number; compliance: number };
export const WEIGHTS = { cashFlow: 0.4, consistency: 0.35, compliance: 0.25 } as const;
export const clamp = (n: number) => Math.max(0, Math.min(100, n));
export const label = (n: number) => (n >= 70 ? "Strong" : n >= 50 ? "Fair" : "Needs a step");
export function computeHealthScore(i: ScoreInput) {
  const total = Math.round(
    clamp(i.cashFlow) * WEIGHTS.cashFlow + clamp(i.consistency) * WEIGHTS.consistency + clamp(i.compliance) * WEIGHTS.compliance);
  const entries = Object.entries(i) as [keyof ScoreInput, number][];
  const weakest = entries.reduce((a, b) => (b[1] < a[1] ? b : a))[0];
  return { total, weakest, parts: entries.map(([k, v]) => ({ key: k, value: clamp(v), label: label(v) })) };
}
