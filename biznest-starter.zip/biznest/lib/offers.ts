export type Offer = { partner: string; amount: number; annualRatePct: number; termMonths: number; fee: number; expiresAt: Date };

/** Standard amortising repayment. Partners must confirm their own figures; this is for comparison display. */
export function monthlyRepayment(amount: number, annualRatePct: number, months: number) {
  const r = annualRatePct / 100 / 12;
  return r === 0 ? amount / months : (amount * r) / (1 - Math.pow(1 + r, -months));
}
export function enrich(o: Offer, now = new Date()) {
  const monthly = monthlyRepayment(o.amount, o.annualRatePct, o.termMonths);
  const totalRepayment = monthly * o.termMonths;
  const daysLeft = Math.ceil((o.expiresAt.getTime() - now.getTime()) / 86_400_000);
  return { ...o, monthly, totalRepayment, totalCost: totalRepayment + o.fee, daysLeft, expiringSoon: daysLeft <= 3 };
}
export type Enriched = ReturnType<typeof enrich>;
/** Index of the best (lowest) value per row, so the UI can highlight differences. */
export function bestIndexes(list: Enriched[]) {
  const min = (f: (o: Enriched) => number) => list.reduce((b, o, i) => (f(o) < f(list[b]) ? i : b), 0);
  return { rate: min((o) => o.annualRatePct), monthly: min((o) => o.monthly), fee: min((o) => o.fee), total: min((o) => o.totalCost) };
}
// Fictional sample data only
export const sampleOffers = (now = new Date()): Offer[] => {
  const d = (n: number) => new Date(now.getTime() + n * 86_400_000);
  return [
    { partner: "Partner A", amount: 100000, annualRatePct: 17, termMonths: 12, fee: 2500, expiresAt: d(5) },
    { partner: "Partner B", amount: 100000, annualRatePct: 16, termMonths: 18, fee: 1500, expiresAt: d(12) },
    { partner: "Partner C", amount: 100000, annualRatePct: 21, termMonths: 6, fee: 3000, expiresAt: d(2) },
  ];
};
