const zar = new Intl.NumberFormat("en-ZA", { style: "currency", currency: "ZAR", maximumFractionDigits: 0 });
export const formatZAR = (n: number) => zar.format(n);
export const formatDate = (d: Date) => d.toLocaleDateString("en-GB"); // DD/MM/YYYY
