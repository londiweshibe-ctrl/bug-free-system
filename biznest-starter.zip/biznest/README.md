# Biznest starter
Mobile-first Next.js PWA starter for Biznest. Screens: Docs, Score, Status, Offers, Data (sample data only).

    pnpm install
    cp .env.example .env
    pnpm dev        # http://localhost:3000
    pnpm test

Not built yet: auth (OTP), file upload API, application and consent flow, partner portal, notifications, admin, PWA manifest.
Before launch: confirm the commission wording, review scoring weights, get POPIA/NCR legal review.
