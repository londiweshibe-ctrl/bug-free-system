import Page from "@/components/Page";
import { Btn, Card } from "@/components/ui";
import { computeHealthScore } from "@/lib/scoring";
const names = { cashFlow: "Cash flow", consistency: "Revenue consistency", compliance: "Compliance" } as const;
export default function Score() {
  const s = computeHealthScore({ cashFlow: 75, consistency: 60, compliance: 45 }); // sample inputs
  return (
    <Page sub="Health" title="Business health">
      <Card>
        <div className="flex items-center gap-4">
          <div className="grid h-[84px] w-[84px] place-items-center rounded-full text-2xl font-bold"
            style={{ background: `conic-gradient(#0B5D45 ${s.total * 3.6}deg, #DDE2DC 0)` }}>
            <span className="grid h-[64px] w-[64px] place-items-center rounded-full bg-white">{s.total}</span>
          </div>
          <div><p className="text-base font-bold">Good start. Room to grow.</p><p className="text-xs text-muted">Sample score. This is guidance, not a verdict.</p></div>
        </div>
      </Card>
      <Card className="!gap-2.5">
        <p className="font-bold">What is shaping your score</p>
        {s.parts.map((p) => (
          <div key={p.key}>
            <div className="flex justify-between text-sm"><span className="font-semibold">{names[p.key]}</span><span className="text-muted">{p.label}</span></div>
            <div className="mt-1 h-2 rounded bg-line"><div className="h-2 rounded bg-brand" style={{ width: `${p.value}%` }} /></div>
          </div>
        ))}
      </Card>
      <Card>
        <p className="text-xs font-bold text-brand">Next best step</p>
        <p className="text-sm">Improve your {names[s.weakest].toLowerCase()}. Upload your tax clearance certificate to lift your compliance score and widen your loan options.</p>
      </Card>
      <Btn>Improve my score</Btn><Btn variant="outline">Apply for funding</Btn>
    </Page>
  );
}
