import Page from "@/components/Page";
import { Card, Muted } from "@/components/ui";
const steps = [
  ["Application received", "Today", true], ["Checked by Biznest", "We confirmed your documents", true],
  ["Sent to 3 partners", "Partner A, Partner B, Partner C", true],
  ["Waiting for offers", "Usually a few working days. We will tell you when one arrives.", false], ["Choose your offer", "You decide. No pressure.", false],
] as const;
export default function Status() {
  return (
    <Page sub="Application" title="Where you are">
      <Card><p className="font-bold">Your application</p><Muted>Request: R 100 000 · stock · 12 months (sample)</Muted></Card>
      <Card className="!gap-3.5">
        {steps.map(([t, s, done]) => (
          <div key={t} className="flex items-start gap-3">
            <span aria-hidden className={`grid h-[22px] w-[22px] flex-none place-items-center rounded-full border-2 border-brand text-xs text-white ${done ? "bg-brand" : "bg-white"}`}>{done ? "✓" : ""}</span>
            <div><p className="text-sm font-semibold">{t}</p><p className="text-xs text-muted">{s}</p></div>
          </div>
        ))}
      </Card>
      <Card><p className="text-sm font-bold">You do not need to do anything now</p><Muted>We will message you the moment an offer lands.</Muted></Card>
      <Card>
        <p className="text-sm font-bold">Tell me by</p>
        <div className="flex flex-wrap gap-2">{["WhatsApp", "SMS", "Push", "Email"].map((c) => (
          <button key={c} aria-pressed="true" className="min-h-11 rounded-full bg-tint px-4 text-sm font-semibold text-brand">{c}</button>))}</div>
      </Card>
    </Page>
  );
}
