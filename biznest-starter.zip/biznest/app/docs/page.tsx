import Page from "@/components/Page";
import { Card, Muted } from "@/components/ui";
import UploadButtons from "@/components/UploadButtons";
const docs = [
  ["ID document", "So we know it is really you", true], ["Business registration", "Proves your business exists", true],
  ["Proof of address", "Needed by lenders", true], ["Bank statements (3 months)", "Unlocks your health score", false],
  ["Financial statements", "Helps you qualify for bigger amounts", false], ["Tax clearance", "Shows you are compliant", false],
] as const;
export default function Docs() {
  const done = docs.filter((d) => d[2]).length;
  return (
    <Page sub="Documents" title="Your documents">
      <Card>
        <p className="font-bold">{done} of {docs.length} documents done</p>
        <div className="h-2 rounded bg-line" role="progressbar" aria-valuenow={done} aria-valuemax={docs.length}>
          <div className="h-2 rounded bg-brand" style={{ width: `${(done / docs.length) * 100}%` }} />
        </div>
        <Muted>Progress is saved. Come back anytime.</Muted>
      </Card>
      <Card className="!gap-0">
        {docs.map(([name, why, ok]) => (
          <div key={name} className="flex justify-between gap-3 border-b border-line py-2 last:border-0">
            <div><p className="text-sm font-semibold">{name}</p><p className="text-xs text-muted">{why}</p></div>
            <p className={`text-sm font-bold ${ok ? "text-brand" : "text-muted"}`}>{ok ? "✓ Done" : "To do"}</p>
          </div>
        ))}
      </Card>
      <Card><p className="text-xs">Your files are encrypted and handled under POPIA. Only lenders you choose to send your application to can see them.</p></Card>
      <UploadButtons label="Upload bank statements" />
    </Page>
  );
}
