import Page from "@/components/Page";
import { Btn, Card, Muted } from "@/components/ui";
export default function Data() {
  const note = process.env.NEXT_PUBLIC_COMMISSION_NOTE || "TODO: confirm the percentage and who pays it before launch.";
  return (
    <Page sub="Privacy" title="Your data, explained">
      <Card className="!gap-0">
        <p className="mb-1 font-bold">Who sees your data, and why</p>
        {[["Biznest team", "To check your documents and build your score"], ["Lending partners", "Only the partners you approve, to price your loan"], ["Nobody else", "We never sell your data"]].map(([t, s]) => (
          <div key={t} className="border-b border-line py-2 last:border-0"><p className="text-sm font-semibold">{t}</p><p className="text-xs text-muted">{s}</p></div>))}
      </Card>
      <Card><p className="font-bold">How Biznest makes money</p><p className="text-sm">We earn a percentage of the loan when a deal is funded. {note} You always see every fee before you accept.</p></Card>
      <Card><p className="font-bold">Your rights under POPIA</p><Muted>Download or delete your data at any time.</Muted></Card>
      <Btn>Manage my data</Btn>
    </Page>
  );
}
