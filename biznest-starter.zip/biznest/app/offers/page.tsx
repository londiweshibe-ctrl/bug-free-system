import Page from "@/components/Page";
import { Btn } from "@/components/ui";
import { bestIndexes, enrich, sampleOffers, type Enriched } from "@/lib/offers";
import { formatZAR } from "@/lib/format";
type Row = { label: string; get: (o: Enriched) => string; best?: number };
export default function Offers() {
  const list = sampleOffers().map((o) => enrich(o));
  const b = bestIndexes(list);
  const rows: Row[] = [
    { label: "Interest rate (per year)", get: (o) => `${o.annualRatePct}%`, best: b.rate },
    { label: "Monthly repayment", get: (o) => formatZAR(o.monthly), best: b.monthly },
    { label: "Term", get: (o) => `${o.termMonths} months` },
    { label: "Fees (shown in full)", get: (o) => formatZAR(o.fee), best: b.fee },
    { label: "Total you repay (before fees)", get: (o) => formatZAR(o.totalRepayment) },
    { label: "Total cost including fees", get: (o) => formatZAR(o.totalCost), best: b.total },
    { label: "Offer expires", get: (o) => (o.expiringSoon ? `${o.daysLeft} days ⚠` : `${o.daysLeft} days`) },
  ];
  return (
    <Page sub="Offers" title="Compare your offers">
      <p className="text-xs text-muted">Sample figures for {formatZAR(list[0].amount)}. The best value in each row is highlighted.</p>
      <div className="grid grid-cols-3 gap-1.5 text-center">
        {list.map((o) => (<div key={o.partner}><span className="mx-auto grid h-8 w-8 place-items-center rounded-full bg-line text-xs font-bold">{o.partner.slice(-1)}</span><p className="text-xs font-bold">{o.partner}</p></div>))}
      </div>
      {rows.map((r) => (
        <div key={r.label}>
          <p className="mb-0.5 text-xs font-semibold text-muted">{r.label}</p>
          <div className="grid grid-cols-3 gap-1.5">
            {list.map((o, i) => (
              <div key={o.partner} className={`rounded-lg border border-line px-1 py-2 text-center text-[13px] font-bold ${r.best === i ? "bg-tint text-brand" : "bg-white"}`}>{r.get(o)}</div>))}
          </div>
        </div>
      ))}
      <div className="flex-1" />
      <Btn>Continue with an offer</Btn>
      <p className="text-xs text-muted">Nothing is final until you sign. We earn a percentage only if you take a loan.</p>
    </Page>
  );
}
