import type { Config } from "tailwindcss";
export default {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: { extend: { colors: { brand: "#0B5D45", gold: "#F2B705", page: "#F5F6F2", ink: "#14201B", muted: "#4A5750", line: "#DDE2DC", tint: "#E3F1EA" } } },
  plugins: [],
} satisfies Config;
