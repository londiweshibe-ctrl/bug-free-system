import { describe, expect, it } from "vitest";
import { computeHealthScore } from "../lib/scoring";
import { bestIndexes, enrich, monthlyRepayment, sampleOffers } from "../lib/offers";

describe("scoring", () => {
  it("weights inputs and finds the weakest area", () => {
    const s = computeHealthScore({ cashFlow: 80, consistency: 60, compliance: 40 });
    expect(s.total).toBe(63);
    expect(s.weakest).toBe("compliance");
  });
});
describe("offers", () => {
  it("handles zero interest", () => expect(monthlyRepayment(1200, 0, 12)).toBe(100));
  it("flags offers expiring within 3 days and picks best per row", () => {
    const list = sampleOffers().map((o) => enrich(o));
    expect(list[2].expiringSoon).toBe(true);
    expect(list[0].expiringSoon).toBe(false);
    expect(bestIndexes(list).rate).toBe(1);
    expect(bestIndexes(list).fee).toBe(1);
  });
});
