import Nav from "./Nav";
export default function Page({ sub, title, children }: { sub: string; title: string; children: React.ReactNode }) {
  return (
    <div className="mx-auto flex min-h-screen max-w-[430px] flex-col bg-page text-ink">
      <header className="bg-brand px-5 pb-4 pt-7 text-white">
        <p className="text-sm font-semibold text-gold">Biznest · {sub}</p>
        <h1 className="text-2xl font-bold">{title}</h1>
      </header>
      <main className="flex flex-1 flex-col gap-3 p-5">{children}</main>
      <Nav />
    </div>
  );
}
