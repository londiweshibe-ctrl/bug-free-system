"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
const tabs = [["Docs", "/docs"], ["Score", "/score"], ["Status", "/status"], ["Offers", "/offers"], ["Data", "/data"]] as const;
export default function Nav() {
  const path = usePathname();
  return (
    <nav aria-label="Main" className="sticky bottom-0 flex border-t border-line bg-white pb-5 pt-3">
      {tabs.map(([label, href]) => (
        <Link key={href} href={href} aria-current={path === href ? "page" : undefined}
          className={`flex-1 py-2 text-center text-xs ${path === href ? "font-bold text-brand" : "text-muted"}`}>{label}</Link>
      ))}
    </nav>
  );
}
