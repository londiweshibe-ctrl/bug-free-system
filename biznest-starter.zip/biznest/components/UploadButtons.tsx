"use client";
import { useRef, useState } from "react";
import { Btn } from "./ui";
export default function UploadButtons({ label }: { label: string }) {
  const cam = useRef<HTMLInputElement>(null), gal = useRef<HTMLInputElement>(null);
  const [names, setNames] = useState<string[]>([]);
  const pick = (e: React.ChangeEvent<HTMLInputElement>) => setNames(Array.from(e.target.files ?? []).map((f) => f.name));
  // TODO: compress images client-side, then upload with a resumable request to /api/documents
  return (
    <div className="flex flex-col gap-2">
      <input ref={cam} type="file" accept="image/*" capture="environment" hidden onChange={pick} />
      <input ref={gal} type="file" accept="image/*,application/pdf" multiple hidden onChange={pick} />
      <Btn onClick={() => gal.current?.click()}>{label}</Btn>
      <div className="flex">
        <button className="min-h-12 flex-1 text-sm font-semibold text-brand" onClick={() => cam.current?.click()}>Take photo</button>
        <button className="min-h-12 flex-1 text-sm font-semibold text-brand" onClick={() => gal.current?.click()}>Choose from gallery</button>
      </div>
      {names.length > 0 && <p className="text-sm text-muted" aria-live="polite">Selected: {names.join(", ")}</p>}
    </div>
  );
}
