import type { ButtonHTMLAttributes } from "react";
export const Card = ({ children, className = "" }: { children: React.ReactNode; className?: string }) =>
  <section className={`flex flex-col gap-1.5 rounded-[14px] border border-line bg-white p-3.5 ${className}`}>{children}</section>;
export const Muted = ({ children }: { children: React.ReactNode }) => <p className="text-sm text-muted">{children}</p>;
export function Btn({ variant = "solid", className = "", ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "solid" | "outline" }) {
  return <button {...p} className={`min-h-12 rounded-xl border-2 border-brand px-4 text-[15px] font-bold ${variant === "solid" ? "bg-brand text-white" : "bg-white text-brand"} ${className}`} />;
}
